package com.example.unshell;

import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.ArrayMap;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.multidex.MultiDexApplication;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import dalvik.system.DexClassLoader;

public class ProxyApplication extends MultiDexApplication {

    public String apkName;
    public String dexPath;
    public String libPath;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        Log.i("提示：","进入attachBaseContext方法!");
        try {
            File dex = this.getDir("payload_odex",MODE_PRIVATE);
            File lib = this.getDir("payload_lib",MODE_PRIVATE);
            dexPath = dex.getAbsolutePath();
            libPath = lib.getAbsolutePath();
            apkName = dex.getAbsolutePath() + "/shell.apk";
            File dexFile = new File(apkName);
            if(!dexFile.exists()){
                dexFile.createNewFile();
                byte[] dexdata = this.readDexFileFromApk();

                // 分离出解壳后的apk文件已用于动态加载
                this.splitPayLoadFromDex(dexdata);
            }

            Object activityThreadObject = RefinvokeMethod.invokeStaticMethod("android.app.ActivityThread","currentActivityThread",new Class[]{},new Object[]{});
            String shellPackageName = this.getPackageName();
            ArrayMap mPackages = (ArrayMap) RefinvokeMethod.getField("android.app.ActivityThread",activityThreadObject,"mPackages");
            WeakReference wr = (WeakReference) mPackages.get(shellPackageName);
            ClassLoader oldCl = (ClassLoader) RefinvokeMethod.getField("android.app.LoadedApk",wr.get(),"mClassLoader");
            DexClassLoader dcl = new DexClassLoader(apkName,dexPath,libPath,oldCl);
            RefinvokeMethod.setField("android.app.LoadedApk","mClassLoader",wr.get(),dcl);
            Log.i("提示：","类加载已被替换成自定义的Dex加载器！");
            try {
                Object objectMain = dcl.loadClass("com.example.forceversion.MainActivity");
                Log.i("提示：","MainActivity.java类加载完毕!");
            }catch (Exception e){
            }
        }catch (Exception e)
        {
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("提示：", "进入onCreate方法!");

        String applicationName = "";
        ApplicationInfo ai = null;
        try {
            ai = this.getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            applicationName = ai.metaData.getString("ApplicationName");
            Log.i("提示：", "成功获取到apk的application名称" + applicationName);
        } catch (Exception e) {
        }

        Object ActivityThreadObj = RefinvokeMethod.invokeStaticMethod("android.app.ActivityThread", "currentActivityThread", new Class[]{}, new Object[]{});
        Object mBoundApplication = RefinvokeMethod.getField("android.app.ActivityThread", ActivityThreadObj, "mBoundApplication");
        Object info = RefinvokeMethod.getField("android.app.ActivityThread$AppBindData", mBoundApplication, "info");

        RefinvokeMethod.setField("android.app.LoadedApk", "mApplication", info, null);
        Object minitApplication = RefinvokeMethod.getField("android.app.ActivityThread", ActivityThreadObj, "mInitialApplication");
        ArrayList<Application> mAllApplications = (ArrayList<Application>) RefinvokeMethod.getField("android.app.ActivityThread", ActivityThreadObj, "mAllApplications");
        mAllApplications.remove(minitApplication);
        ApplicationInfo mApplicationInfo = (ApplicationInfo) RefinvokeMethod.getField("android.app.LoadedApk", info, "mApplicationInfo");
        ApplicationInfo appInfo = (ApplicationInfo) RefinvokeMethod.getField("android.app.ActivityThread$AppBindData", mBoundApplication, "appInfo");

        mApplicationInfo.className = applicationName;
        appInfo.className = applicationName;

        Application app = (Application) RefinvokeMethod.invokeMethod("android.app.LoadedApk", "makeApplication", info, new Class[]{boolean.class, Instrumentation.class}, new Object[]{false, null});
        Log.i("提示：","app: " + app);
        RefinvokeMethod.setField("android.app.ActivityThread", "mInitialApplication", ActivityThreadObj, app);

        ArrayMap mProviderMap = (ArrayMap) RefinvokeMethod.getField("android.app.ActivityThread", ActivityThreadObj, "mProviderMap");
        Iterator it = mProviderMap.values().iterator();

        while (it.hasNext()) {
            Object mProviderClientRecord = it.next();
            Object mLocalProvider = RefinvokeMethod.getField("android.app.ActivityThread$ProviderClientRecord", mProviderClientRecord, "mLocalProvider");
            RefinvokeMethod.setField("android.content.ContentProvider", "mContext", mLocalProvider, app);
        }

        Log.i("提示：", "反射appliction完成，准备拉起源apk！");

        app.onCreate();

        Log.i("提示：", "源apk成功拉起！脱壳完毕！");
    }

    public byte[] readDexByte() throws IOException
    {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ZipInputStream zipInputStream = new ZipInputStream(new BufferedInputStream(new FileInputStream(this.getApplicationInfo().sourceDir))); /*获取应用存放数据文件的输入流*/
        while (true)
        {
            ZipEntry zipEntry = zipInputStream.getNextEntry();
            if (zipEntry == null)
            {
                zipInputStream.close();
                break;
            }
            if (zipEntry.getName().equals("classes.dex"))
            {
                byte[] aByte = new byte[1024];
                while (true)
                {
                    int i = zipInputStream.read(aByte);
                    if (i == -1)
                    {
                        break;
                    }
                    byteArrayOutputStream.write(aByte,0,i);
                }
            }
            zipInputStream.closeEntry();
        }
        zipInputStream.close();
        return byteArrayOutputStream.toByteArray();
    }

    public void getSourceApk(byte[] data) throws Exception
    {
        int dexLength = data.length;
        byte[] sourceDexLen = new byte[4];
        System.arraycopy(data,dexLength-4,sourceDexLen,0,4);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(sourceDexLen);
        DataInputStream in = new DataInputStream(byteArrayInputStream);
        int unshellLen = in.readInt();
        Log.i("unshell length:", String.valueOf(unshellLen));
        byte[] newdex = new byte[unshellLen];
        System.arraycopy(data,dexLength-4-unshellLen,newdex,0,unshellLen);
        File file = new File(apkName);
        try{
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(newdex);
            fos.close();
            Log.i("提示：","成功取出源数据，成功还原为apk包，文件名为"+apkName);
        }catch (Exception e){
        }
    }

    private void splitPayLoadFromDex(byte[] apkdata) throws IOException {
        int ablen = apkdata.length;
        //取被加壳apk的长度   这里的长度取值，对应加壳时长度的赋值都可以做些简化
        byte[] dexlen = new byte[4];
        System.arraycopy(apkdata, ablen - 4, dexlen, 0, 4);
        ByteArrayInputStream bais = new ByteArrayInputStream(dexlen);
        DataInputStream in = new DataInputStream(bais);
        int readInt = in.readInt();
        System.out.println(Integer.toHexString(readInt));
        byte[] newdex = new byte[readInt];
        //把被加壳apk内容拷贝到newdex中
        System.arraycopy(apkdata, ablen - 4 - readInt, newdex, 0, readInt);
        //这里应该加上对于apk的解密操作，若加壳是加密处理的话
        //?

        //对源程序Apk进行解密
        newdex = decrypt(newdex);

        //写入apk文件
        File file = new File(apkName);
        try {
            FileOutputStream localFileOutputStream = new FileOutputStream(file);
            localFileOutputStream.write(newdex);
            localFileOutputStream.close();
        } catch (IOException localIOException) {
            throw new RuntimeException(localIOException);
        }

        //分析被加壳的apk文件
        ZipInputStream localZipInputStream = new ZipInputStream(
                new BufferedInputStream(new FileInputStream(file)));
        while (true) {
            ZipEntry localZipEntry = localZipInputStream.getNextEntry();//不了解这个是否也遍历子目录，看样子应该是遍历的
            if (localZipEntry == null) {
                localZipInputStream.close();
                break;
            }
            //取出被加壳apk用到的so文件，放到 libPath中（data/data/包名/payload_lib)
            String name = localZipEntry.getName();
            if (name.startsWith("lib/") && name.endsWith(".so")) {
                File storeFile = new File(libPath + "/"
                        + name.substring(name.lastIndexOf('/')));
                storeFile.createNewFile();
                FileOutputStream fos = new FileOutputStream(storeFile);
                byte[] arrayOfByte = new byte[1024];
                while (true) {
                    int i = localZipInputStream.read(arrayOfByte);
                    if (i == -1)
                        break;
                    fos.write(arrayOfByte, 0, i);
                }
                fos.flush();
                fos.close();
            }
            localZipInputStream.closeEntry();
        }
        localZipInputStream.close();


    }

    private byte[] readDexFileFromApk() throws IOException {
        ByteArrayOutputStream dexByteArrayOutputStream = new ByteArrayOutputStream();
        ZipInputStream localZipInputStream = new ZipInputStream(
                new BufferedInputStream(new FileInputStream(
                        this.getApplicationInfo().sourceDir)));
        while (true) {
            ZipEntry localZipEntry = localZipInputStream.getNextEntry();
            if (localZipEntry == null) {
                localZipInputStream.close();
                break;
            }
            if (localZipEntry.getName().equals("classes.dex")) {
                byte[] arrayOfByte = new byte[1024];
                while (true) {
                    int i = localZipInputStream.read(arrayOfByte);
                    if (i == -1)
                        break;
                    dexByteArrayOutputStream.write(arrayOfByte, 0, i);
                }
            }
            localZipInputStream.closeEntry();
        }
        localZipInputStream.close();
        return dexByteArrayOutputStream.toByteArray();
    }

    private byte[] decrypt(byte[] srcdata) {
        for(int i=0;i<srcdata.length;i++){
            srcdata[i] = (byte)(0xFF ^ srcdata[i]);
        }
        return srcdata;
    }
}

