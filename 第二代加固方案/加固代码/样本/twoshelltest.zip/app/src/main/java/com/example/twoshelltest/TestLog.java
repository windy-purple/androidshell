package com.example.twoshelltest;

import android.util.Log;

public class TestLog {
    public void printLog(){
        Log.i("twoshell","source apk==>TestLog.printLog");
    }
}
