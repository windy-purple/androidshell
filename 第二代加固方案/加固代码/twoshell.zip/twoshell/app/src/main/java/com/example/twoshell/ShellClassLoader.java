package com.example.twoshell;

import android.content.Context;
import android.util.Log;

import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;
import dalvik.system.DexFile;

public class ShellClassLoader extends DexClassLoader {

    public String tag = "twoshell";
    public int cookie;
    public Context mcontent;
    public ClassLoader ml;

    public ShellClassLoader(Context context, String dexPath, String optimizedDirectory, String librarySearchPath, ClassLoader parent,byte[] dexbyte) {
        super(dexPath, optimizedDirectory, librarySearchPath, parent);
        this.mcontent = context;
        this.ml = parent;
        cookie = ShellNativeMethod.loadDexFile(dexbyte,dexbyte.length);
        //cookie = (Integer)RefinvokeMethod.invokeDeclaredMethod(DexFile.class.getName(),"openDexFile",new Class[]{Object.class},new Object[]{dexbyte});
        Log.i(tag,"cookie: " + cookie);
    }

    private String[] getClassNameList(int flag)
    {
        Log.i(tag,"class==> " + DexFile.class.getName());
        String[] sl = (String[]) RefinvokeMethod.invokeDeclaredMethod(DexFile.class.getName(),"getClassNameList",new Class[]{int.class},new Object[]{flag});
        return sl;
    }

    private Class defineClass(String name,ClassLoader cl,int cookie)
    {
        Log.i(tag,"define class name is " + name);
        Class ca = (Class)RefinvokeMethod.invokeDeclaredMethod(DexFile.class.getName(),"defineClassNative",new Class[]{String.class,ClassLoader.class,int.class},new Object[]{name,cl,cookie});
        return ca;
    }

    protected Class<?> findClass(String name) throws ClassNotFoundException
    {
        Log.i(tag,"start found class " + name);
        int i;
        Class<?> cls = null;
        String[] classnamelist = getClassNameList(cookie);
        Log.i(tag, String.valueOf(classnamelist));
        for (i = 0;i < classnamelist.length;i++)
        {
            Log.i(tag,"find class " + classnamelist[i]);
            if (name.equals(classnamelist[i]))
            {
                cls = defineClass(classnamelist[i].replace('.','/'),mcontent.getClassLoader(),cookie);
            }
            else
            {
                defineClass(classnamelist[i].replace('.','/'),mcontent.getClassLoader(),cookie);
            }
        }
        if(cls == null)
        {
            Log.i(tag,"not found class " + name);
            cls = super.findClass(name);
        }
        return cls;
    }

    protected Class<?> loadClass(String classname,boolean mark) throws ClassNotFoundException
    {
        Log.i(tag,"start load class " + classname);
        try{
            Class clzDexFile = Class.forName("dalvik.system.DexFile");
            Method method = clzDexFile.getDeclaredMethod("defineClassNative",String.class,ClassLoader.class,int.class);
            method.setAccessible(true);
            Class clz = (Class)method.invoke(null,new Object[]{classname,ml,cookie});
            Log.i(tag,"loadClass return not null");
            return clz;
        }catch (Exception e){
            e.printStackTrace();
        }
        Log.i(tag,"loadClass return is null");
        return null;
        /*Class<?> cls = super.loadClass(classname,mark);
        if (cls == null)
        {
            Log.i(tag,"error,not found class " + classname);
        }
        return cls;*/
    }
}
