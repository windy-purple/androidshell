package com.example.twoshell;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.ArrayMap;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;

public class MainActivity extends AppCompatActivity {

    private String tag = "twoshell";

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        byte[] dexContent = readDex();
        Log.i(tag,"加载dex文件完成");
        Object activityThreadObject = RefinvokeMethod.invokeStaticMethod("android.app.ActivityThread","currentActivityThread",new Class[]{},new Object[]{});
        String shellPackageName = this.getPackageName();
        ArrayMap mPackages = (ArrayMap) RefinvokeMethod.getField("android.app.ActivityThread",activityThreadObject,"mPackages");
        WeakReference wr = (WeakReference) mPackages.get(shellPackageName);
        ClassLoader oldCl = (ClassLoader) RefinvokeMethod.getField("android.app.LoadedApk",wr.get(),"mClassLoader");
        ShellClassLoader scl = new ShellClassLoader(getApplicationContext(),getPackageResourcePath(),getDir(".dex",MODE_PRIVATE).getAbsolutePath(),null,oldCl,dexContent);
        try{
            Class<?> classm = scl.loadClass("com.example.twoshelltest.TestLog");
            Method method = classm.getMethod("printLog");
            method.invoke(classm.newInstance());
            Log.i(tag,"loading MainActivity class");
            //Intent intent = new Intent(this,classm);
            //startActivity(intent);
            Log.i(tag,"jump to class MainActivity");
        }catch (Exception e){
            Log.i(tag,Log.getStackTraceString(e));
        }
        RefinvokeMethod.setField("android.app.LoadedApk","mClassLoader",wr.get(),scl);
    }

    public byte[] readDex(){
        ByteArrayOutputStream bos = null;
        byte[] buffer = new byte[1024];
        byte[] bu = new byte[100];
        try{
            InputStream is = getAssets().open("classes.dex");
            bos = new ByteArrayOutputStream();
            int i;
            int k = 0;
            while ((i = is.read(buffer)) != -1){
                bos.write(buffer,0,i);
                if (k == 0)
                {
                    System.arraycopy(buffer,0,bu,0,100);
                    k++;
                }
            }
            bos.flush();
            Log.i(tag, String.valueOf(bu));
        }catch (IOException e) {
        }
        return bos.toByteArray();
    }
}
