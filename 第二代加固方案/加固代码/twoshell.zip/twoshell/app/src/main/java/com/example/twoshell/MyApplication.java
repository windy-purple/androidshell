package com.example.twoshell;

import android.app.Application;
import android.content.Context;

public class MyApplication extends Application {

    private Context mcontent;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        mcontent = base;
    }
}
