package com.example.twoshell;

public class ShellNativeMethod {

    static{
        System.loadLibrary("twoshell");
    }

    public static native int loadDexFile(byte[] dex,long dexlen);
}
