package com.example.threeshell;

public class ThreeShellNativeMethod {

    static {
        System.loadLibrary("threeshell");
    }

    public static native void hookcode();
    public static native int loadDexFile(byte[] dex,long dexlen);
}
