#include <stdio.h>
#include <string.h>
#include <jni.h>
#include "datadefine.h"
#include <stdlib.h>
#include <dlfcn.h>
#include "DexFile.h"
#include "DexClass.h"
#include "Common.h"
#include "include/inlineHook.h"
#include "com_example_threeshell_ThreeShellNativeMethod.h"

#include <android/log.h>

#define  LOG_TAG    "threeshell"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

JNINativeMethod *dexfile;
void (*openDexFile)(const u4* args, union JValue* pResult);

int checkFunction(JNINativeMethod *table,const char *name,const char *sig,void(**fnPtrout)(u4 const *,union JValue *));

const DexClassDef* (*olddexFindClass)(const DexFile* pFile,const char* descriptor);

const DexClassDef* newDexFindClass(const DexFile* pFile,const char* descriptor){
    int cmp = strcmp("Lcom/example/threeshelltest/TestLog;",descriptor);
    if(cmp == 0){
        const DexClassDef* pClassOff = olddexFindClass(pFile,descriptor);
        if(pClassOff == NULL){
            return pClassOff;
        }
        DexClassData* pClassData = reinterpret_cast<DexClassData *>(pClassOff->classDataOff);
        DexClassDataHeader header = pClassData->header;
        LOGI("direct method size is %d",header.directMethodsSize);
        DexMethod* pDexDirectMethod = pClassData->directMethods;
        u1* ptr = (u1*)pDexDirectMethod;
        for(int i = 0;i < header.directMethodsSize;i++){
            pDexDirectMethod = (DexMethod*)(ptr + sizeof(DexMethod) * i);
            const DexMethodId* methodid = dexGetMethodId(pFile,pDexDirectMethod->methodIdx);
            const char* methodName = dexStringById(pFile,methodid->nameIdx);
            if(strcmp("getnum",methodName) == 0){
                LOGI("The name of way which be remarked is %s",methodName);
                DexCode* dexcode = (DexCode*)dexGetCode(pFile,pDexDirectMethod);
                u2 new_ins[4] = {0x12,0x10,0x0f,0x00};
                memcpy(dexcode->insns,&new_ins,4 * sizeof(u2));
                LOGI("Memory reverse");
            }
        }
    }
}

int checkFunction(JNINativeMethod *table,const char *name,const char *sig,void(**fnPtrout)(u4 const *,union JValue *))
{
    int i = 0;
    while(table[i].name != NULL)
    {
        LOGI("check size is %d, function name is %s",i,table[i].name);
        if((strcmp(name,table[i].name) == 0) && (strcmp(sig,table[i].signature) == 0))
        {
            *fnPtrout = table[i].fnPtr;
            return 1;
        }
        i++;
    }
    return 0;
}

void* getDexFindClassAddress(void* funclib){
    void* func = dlsym(funclib,"_Z12dexFindClassPK7DexFilePKc");
    LOGI("func: %p",func);
    if(registerInLineHook((uint32_t)func,(uint32_t)newDexFindClass,(uint32_t)&olddexFindClass) != ELE7EN_OK){
        LOGI("hook error 1");
        return NULL;
    }
    return func;
}

void hookSystemFunction(){
    void* dvmlib = (void*)dlopen("libdvm.so",RTLD_LAZY);
    LOGI("dvmib: %p",dvmlib);
    void* func = getDexFindClassAddress(dvmlib);
    if(inlineHook((uint32_t)func) != ELE7EN_OK){
        LOGI("hook error 2");
        return;
    }
}

extern "C" JNIEXPORT void JNICALL Java_com_example_threeshell_ThreeShellNativeMethod_hookcode(JNIEnv *env, jclass jc){
    LOGI("HOOK dexFindClass start");
    hookSystemFunction();
    LOGI("HOOK dexFindClass finish");
}

extern "C" JNIEXPORT jint JNICALL Java_com_example_threeshell_ThreeShellNativeMethod_loadDexFile(JNIEnv *env, jclass jc, jbyteArray dexbyte, jlong dexsize){
    char *arr;
    union JValue presult;
    jint result;
    u1 *olddex = (u1*)(*env)->GetByteArrayElements(env,dexbyte,NULL);
    arr = (char*)malloc(16 + dexsize);
    ArrayObject *ao = (ArrayObject*)arr;
    ao->length = dexsize;
    memcpy(arr + 16,olddex,dexsize);
    u4 args[] = {(u4)ao};
    if(openDexFile != NULL)
    {
        openDexFile(args,&presult);
    }
    else
    {
        result = -1;
    }
    result = (jint)presult.l;
    LOGI("openDexFile Function Result is %d",result);
    return result;
}

JNIEXPORT jint JNI_OnLoad(JavaVM* jv, void* reserved)
{
    void *env;
    void *sofile = (void*)dlopen("libdvm.so",RTLD_LAZY);
    dexfile = (JNINativeMethod*)dlsym(sofile,"dvm_dalvik_system_DexFile");
    if(checkFunction(dexfile,"openDexFile","([B)I",&openDexFile) == 0)
    {
        openDexFile = NULL;
        LOGI("not found openDexFile method!");
    }
    else
    {
        LOGI("found openDexFile method!");
    }
    return JNI_VERSION_1_4;
}