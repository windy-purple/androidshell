package com.example.threeshelltest;

import android.util.Log;

public class TestLog {

    public void printLog(){
        int a = getnum();
        Log.i("threeshell","source apk==>" + a);
    }

    public int getnum(){
        return 1;
    }
}
